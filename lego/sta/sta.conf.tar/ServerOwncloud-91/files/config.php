<?php
$CONFIG = array (
  'updatechecker' => false,
  'instanceid' => 'oc6cdfaivqhu',
  'passwordsalt' => '4bC9tT0DbKN7eZ/ZC4FmZI97AO3RMa',
  'secret' => 'ab+1rcTYx6SQHqJULaVcbvwSHBG4vt+oBxTUR+nA9lD2xmS3',
  'trusted_domains' => 
  array (
    0 => '192.168.91.6',
    1 => 'owncloud.fb.com',
    2 => 'owncloud.ig.com',
  ),
  'datadirectory' => '/var/www/owncloud/data',
  'overwrite.cli.url' => 'http://192.168.91.6/owncloud',
  'dbtype' => 'sqlite3',
  'version' => '9.0.10.2',
  'logtimezone' => 'UTC',
  'installed' => true,
  'asset-pipeline.enabled' => true,
  'ldapIgnoreNamingRules' => false,
);
